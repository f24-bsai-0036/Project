;register to register
;mov ax, bx

;register to memory
;mov[100h], ax
;mov ax, [100h]

;immediate value to register
;mov ax, 5

;indirect
; mov ax [(bx)]

;exchange value

;special purpose registers

;increment and decrement

.model small
.stack 100h
.data
.code
main proc
    
    mov DS, AX

    mov AX, 3

    mov BX, AX

    mov 5, BX

    mov AX, 9

    xchg AX, BX

    inc AX         
    dec BX         

    mov AX, 4C00h  
    int 21h         

    main endp
endp