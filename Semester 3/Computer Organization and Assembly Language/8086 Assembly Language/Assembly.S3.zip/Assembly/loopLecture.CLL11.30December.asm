.model small
.stack 100h
.data
.code
main proc
    
    mov CX, 10 
    mov DX, 48
    L1:
    mov AH, 2
    int 21h
    add DX, 2
    LOOP L1
    
    mov AH, 4ch
    int 21h
    
    main endp
end main