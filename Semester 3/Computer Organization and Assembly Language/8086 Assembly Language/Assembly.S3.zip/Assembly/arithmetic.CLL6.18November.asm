; 0 = 48 = 30h
; 1 = 49 = 31h
; 2 = 50
; 3 = 51
; df means define byte


;.model small

;.stack 100h

;.data

;.code

;main proc
    
;    mov AL, 5

;    mov BL, 4

;    add AL, BL

;    add AL, 30h
    
;    mov DL, AL
    
;    mov AH, 2
    
;    main endp

;endp



;.model small

;.stack 100h

;.data

;.code

;main proc
    
;    MOV AL, 5
    
;    MOV BL, 4
    
;    MUL BL

;    MOV DX, 0
    
;    MOV AX, 100
    
;    MOV BX, 7
    
;    DIV BX
       
;    main endp

;endp 

.model small
.stack 100h
.data
q db ?
r db ?
.code
main proc
    
    mov AX, @data
    
    mov DS, AX
    
    mov AX, 9
    
    mov BL, 2
    
    div BL
    
    add AL, 48
    
    mov DL, AL
    
    mov AH, 2
    
    int 21h
    
    mov AH, 4ch
    
    int 21h
    
    main endp

end main