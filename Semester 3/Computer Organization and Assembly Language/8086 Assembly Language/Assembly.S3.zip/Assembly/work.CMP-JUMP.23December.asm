.model small
.stack 100h
.data
msgEqual db "Number is equal.$"
msgGreater db "Number is greater.$"
msgLesser db "Number is lesser.$"

.code
main proc
    mov AX, @data
    mov DS, AX
    ; Read a character from user
    mov AH, 1
    int 21h
    sub AL, '0'        ; Convert ASCII to number

    mov BL, 5          ; Compare with 5

    CMP AL, BL
    JE equalLABEL
    JG greaterLABEL
    JL lesserLABEL

equalLabel:
    mov DX, offset msgEqual
    mov AH, 09h
    int 21h
    JMP endProgram

greaterLABEL:
    mov DX, offset msgGreater
    mov AH, 09h
    int 21h
    JMP endProgram

lesserLabel:
    mov DX, offset msgLesser
    mov AH, 09h
    int 21h

endProgram:
    mov AH, 4Ch
    int 21h
main endp
end main