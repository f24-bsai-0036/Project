;10 newLine
;13 carriageReturn
.model small
.stack 100h
.data
messageOne db "University of Karachi.$"
messageTwo db "Riphah International University, Sahiwal City Campus.$"
.code
main proc
    
    mov AX, @data
    mov DS, AX
    
    mov DX, offset messageOne
    mov AH, 09
    int 21h
    
    mov DX, 10
    mov AH, 2
    int 21h
    
    mov DX, 13
    mov AH, 2
    int 21h
    
    mov DX, offset messageTwo
    mov AH, 09
    int 21h   
       
    mov AH, 4ch
    int 21h
    
    main endp
end main              