.model small
.stack 100h
.data
.code
main proc
    
    mov AH, 1 ; for input = 1
    int 21H
    mov DL, AH
    mov AH, 2
     
    mov AH, 1
    int 21H
    mov DL, AH
    mov AH, 2
    
    mov AH, 1
    int 21H
    mov DL, AH
    mov AH, 2
 
    mov AH, 1
    int 21H
    mov DL, AH
    mov AH, 2
  
    mov AH, 1
    int 21H
    mov DL, AH
    mov AH, 2
 
    mov AH, 1
    int 21H
    mov DL, AH
    mov AH, 2
    
    mov AH, 1
    int 21H
    mov DL, AH
    mov AH, 2
 
    
    mov AH, 4ch ;for exit = 4ch
    INT 21H
    
    main endp
end main