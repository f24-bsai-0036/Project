org 100h

start:
    ; Get system time
    mov ah, 2Ch         ; BIOS service to get time
    int 21h             ; Returns: CH = hour, CL = minute, DH = second

    ; Save values to registers
    mov bh, ch          ; Store hour
    mov bl, cl          ; Store minute
    mov dl, dh          ; Store second

    ; Print "Time: "
    mov dx, offset label_time
    mov ah, 09h
    int 21h

    ; Print HH:
    mov al, bh
    call PrintByte

    mov dl, ':'         
    mov ah, 02h
    int 21h

    ; Print MM:
    mov al, bl
    call PrintByte

    mov dl, ':'         
    mov ah, 02h
    int 21h

    ; Print SS
    mov al, dl
    call PrintByte

    ; Return to DOS
    mov ah, 4Ch
    int 21h

; -----------------------
; Procedure to print byte as two ASCII digits
; -----------------------
PrintByte:
    push ax
    push dx

    mov ah, 0
    mov dl, 10
    div dl              ; AL / 10 ? quotient in AL, remainder in AH

    add al, '0'         ; Tens digit
    mov ah, 02h
    int 21h

    mov al, ah          ; Ones digit
    add al, '0'
    mov ah, 02h
    int 21h

    pop dx
    pop ax
    ret

; -----------------------
; Data
; -----------------------
label_time db 'Time: $'
