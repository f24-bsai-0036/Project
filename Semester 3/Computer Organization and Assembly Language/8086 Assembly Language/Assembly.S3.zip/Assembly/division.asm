.model small
.stack 100h
.data
.code
main proc
     
    mov AL, 5
    mov AH, 0
    mov BL, 2
    div BL
    add AL, 30h
    mov DL, AL
    mov AH, 2
    int 21h

    main endp
end main