.model small
.stack 100h
.data
msg db "Riphah International University, Sahiwal City Campus.$"
.code
main proc
    
    mov AX, @data
    mov DS, AX
    
    mov AH, 09
    lea DX, msg
    int 21h
    
    mov AH, 4ch
    int 21h
    
    main endp
end main