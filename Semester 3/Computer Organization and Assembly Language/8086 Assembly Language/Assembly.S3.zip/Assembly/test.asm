.model small
.stack 100h
.data
number db 2, 3, 4, 5, 7
count  dw 5
.code
main proc

    mov AX, @data
    mov DS, AX

    mov SI, offset number
    mov CX, count
    mov AL, 0

summation:
    add AL, [SI]
    inc SI
    loop summation

    ; ---- convert sum in AL to �ree decimal digits ----
    mov AH, 0
    mov BL, 100
    div BL          ; AL = hundreds, AH = remainder

    mov BH, AL      ; save hundreds
    mov AL, AH

    mov AH, 0
    mov BL, 10
    div BL          ; AL = tens, AH = ones

    mov CL, AL      ; save tens
    mov CH, AH      ; save ones

    ; ---- print hundreds ----
    add BH, 48
    mov DL, BH
    mov AH, 2
    int 21h

    ; ---- print tens ----
    add CL, 48
    mov DL, CL
    mov AH, 2
    int 21h

    ; ---- print ones ----
    add CH, 48
    mov DL, CH
    mov AH, 2
    int 21h

    mov AH, 4Ch
    int 21h

main endp
end main
