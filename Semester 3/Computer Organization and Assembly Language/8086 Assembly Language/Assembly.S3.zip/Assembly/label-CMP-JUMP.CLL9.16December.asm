.model small
.stack 100h
.data
messageOne db "Login successful.$"
messageTwo db "Access denied.$"
.code
main proc
    
    mov AX, @data
    mov DS, AX
    
    mov DL, '3'
    
    mov AH, 1
    int 21h
    
    CMP AL, DL
    JNE LabelOne
    
    mov AX, offset messageOne
    mov AH, 09
    int 21h
    mov AH, 4ch
    int 21h
    
    LabelOne:
    mov DX, offset messageTwo
    mov AH, 09
    int 21h
    
    mov AH, 4ch
    int 21h
    
    main endp
end main