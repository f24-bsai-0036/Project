.model small
.stack 100h
.data
.code
main proc
    
    mov AX, 0111b
    SHL AX, 2
    
    main endp
end main