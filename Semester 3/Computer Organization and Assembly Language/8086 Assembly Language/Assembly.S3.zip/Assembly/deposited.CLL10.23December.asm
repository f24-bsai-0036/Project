.model small
.stack 100h
.data
messageOne db 13, 10, "Balance: $"
messageTwo db 13, 10, "Deposited: $"
positiveMessage db 13, 10, "Remaining is Positive.$"
negativeMessage db 13, 10, "Reamining is Negative.$"
.code
main proc
    
    mov AX, @data
    mov DS, AX
    
    lea DX, messageOne
    mov AH, 9
    int 21h
    
    mov AH, 1
    int 21h
    mov AL, 30h
    mov BL, AL
    
    lea DX, messageTwo
    mov AH, 9
    int 21h
    
    mov AH, 1
    int 21h
    sub AL, 48h
    mov BH, AL
    mov AL, BL
    sub AL, BH
    
    JS negative
    
    lea DX, positiveMessage
    JMP print
    negative:
    lea DX, negativeMessage
    print:
    mov AH, 9
    int 21h
    
    mov AH, 4ch
    int 21h
    
    main endp
end main                                                                            