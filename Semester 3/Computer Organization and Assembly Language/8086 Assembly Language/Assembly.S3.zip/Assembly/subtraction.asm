.model small
.stack 100h
.data
.code
main proc
     
    mov AL, 5
    sub AL, 4
    add AL, 30h
    mov DL, AL
    mov AH, 2
    int 21h
    
    main endp
end main