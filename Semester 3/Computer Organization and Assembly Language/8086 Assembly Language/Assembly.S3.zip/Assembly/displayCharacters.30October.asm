.model small
.stack 100h
.data
.code
main proc
    
    mov DL, 'M'
    mov AH, 2
    INT 21H
    mov DL, 'U'
    mov AH, 2
    INT 21H
    mov DL, 'I'
    mov AH, 2
    INT 21H
    mov DL, 'Z'
    mov AH, 2
    INT 21H
    mov Dl, 'Z'
    mov AH, 2
    INT 21H
    
    main endp
end main