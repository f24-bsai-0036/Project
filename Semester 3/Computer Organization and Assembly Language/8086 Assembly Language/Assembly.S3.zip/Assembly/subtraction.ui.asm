.model small
.stack 100h
.data
.code
main proc
      
    mov ah, 1
    int 21h
    sub al, 30h
    mov bl, al

    mov ah, 1
    int 21h
    sub al, 30h
    sub bl, al

    add bl, 30h
    mov dl, bl
    mov ah, 2
    int 21h

    
main endp
end main