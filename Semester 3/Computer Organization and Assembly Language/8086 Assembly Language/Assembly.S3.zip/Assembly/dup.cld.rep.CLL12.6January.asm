.model small
.stack 100h
.data
forSource db "Riphah International University, Sahiwal City Campus.$"
forPosition db 54 dup ("$")
.code
main proc
    
    mov AX, @data
    mov DS, AX
    mov ES, AX
    
    lea SI, forSource
    lea DI, forPosition
    
    mov CX, 54
    cld
    
    REP movsb
    
    lea DX, forPosition
    
    mov AH, 09
    int 21h
    
    mov AH, 4ch
    int 21h
    
    main endp
end main