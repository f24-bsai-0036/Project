.model small
.stack 100h
.data
.code
main proc
    
    mov AH, 1
    int 21h
    sub AL, 30h     
    mov BL, AL
     
    mov AH, 1
    int 21h
    sub AL, 30h
    add AL, BL    
    add AL, 30h     

    mov DL, AL
    mov AH, 2
    int 21h

    mov AH, 4ch
    int 21h
    
main endp
end main
