.model small
.stack 100h
.data
number db 2, 3, 4, 5, 7
count dw 5
.code
main proc
    
    mov AX, @data ;heap address not actual (for heap, offset is used? then actual address is given) 
    mov DS, AX                                       
    
    mov SI, offset number
    mov CX, count
    mov AL, 0
     
    summation:
    add AL, [SI]
    inc SI
    
    LOOP summation
    
    mov AH, 0
    mov BL, 10
    
    div BL
    mov BH, AH
    
    add AL, 48
    mov DL, AL
    mov AH, 2
    int 21h
    
    add BH, 48
    mov DL, BH 
    mov AH, 2
    int 21h
    
    mov AH, 4ch
    int 21h
    
    main endp
end main
; this is 2 digit, assignment of 3 digit 