.model small
.stack 100h
.data
msg db "Riphah International University, Sahiwal City Campus$"
.code
main proc
    
    mov AX, @data
    mov DS, AX
    mov AH, 09H
    INT 21H
    
    mov AH, 09h  
    mov DL, msg
    INT 21H
    
    mov AH, 4ch
    INT 21H
    
    
    
    mov DL, 'M'
    mov AH, 2
    INT 21H
    mov DL, 'U'
    mov AH, 2
    INT 21H
    mov DL, 'I'
    mov AH, 2
    INT 21H
    mov DL, 'Z'
    mov AH, 2
    INT 21H
    mov Dl, 'Z'
    mov AH, 2
    INT 21H
    
    main endp
end main
