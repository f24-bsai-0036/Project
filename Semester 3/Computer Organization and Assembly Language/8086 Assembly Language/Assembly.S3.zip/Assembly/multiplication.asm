.model small
.stack 100h
.data
.code
main proc
     
    mov AL, 3
    mov BL, 3
    mul BL
    add AL, 30h
    mov DL, AL
    mov AH, 2
    int 21h
 
    main endp
end main