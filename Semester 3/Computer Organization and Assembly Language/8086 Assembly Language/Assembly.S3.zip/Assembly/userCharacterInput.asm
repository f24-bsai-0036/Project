.model small
.stack 100h
.data
.code
main proc
    
    mov AH, 1
    int 21h
    mov DL, AH
    mov AH, 2
    
    mov AX, 4ch
    int 21h
    
    main endp
end main